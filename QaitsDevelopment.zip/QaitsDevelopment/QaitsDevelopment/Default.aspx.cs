﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
using System.IO;
using MyPerson;

namespace QaitsDevelopment
{
    public partial class _Default : System.Web.UI.Page
    {
        //Setting the database privallages
        SqlConnection dbConnection;
        string sqlcon;
        SqlCommand comm;
        SqlDataReader read;

        //Method for connecting to the database
        private void Connection()
        {
               sqlcon = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
               dbConnection = new SqlConnection(sqlcon);
        }

        //Method for inserting to the database.
        private void InsertCSVRecords(DataTable csvdt)
        {
            Connection();
            //Creating object of the SQLBulkCopy
            SqlBulkCopy objBulk = new SqlBulkCopy(dbConnection);
            //Assigning Destination table name
            objBulk.DestinationTableName = "Person_Infor";
            //Mapping the table colomn
            objBulk.ColumnMappings.Add("Id", "Id");
            objBulk.ColumnMappings.Add("FirstName", "FirstName");
            objBulk.ColumnMappings.Add("Surname", "Surname");
            objBulk.ColumnMappings.Add("Age", "Age");
            objBulk.ColumnMappings.Add("Sex" ,"Sex");
            objBulk.ColumnMappings.Add("Mobile", "Mobile");
            objBulk.ColumnMappings.Add("Active", "Active");
            
            //Inserting data to the database
            dbConnection.Open();
            objBulk.WriteToServer(csvdt);
            dbConnection.Close();

        }

        protected void Page_Load(object sender, EventArgs e)
        {
            
        }

        protected void btnUpload_Click(object sender, EventArgs e)
        {
            try
            {
                //Writing the code for creating the object of the database
                DataTable tblcsv = new DataTable();
                //Creating colomns
                tblcsv.Columns.Add("Id");
                tblcsv.Columns.Add("FirstName");
                tblcsv.Columns.Add("Surname");
                tblcsv.Columns.Add("Age");
                tblcsv.Columns.Add("Sex");
                tblcsv.Columns.Add("Mobile");
                tblcsv.Columns.Add("Active");

                //Getting full file path of the upload file
                string csvFilePath = Path.GetFileName(FileUpload1.PostedFile.FileName);

                //Reading All text
                string readCSV = File.ReadAllText(@"C:\Users\SIKHUMBUZO\Desktop\DeveloperInstructions\Person.csv");

                //Spliting row after new line
                foreach (string csvRow in readCSV.Split('\n'))
                {
                    if (!string.IsNullOrEmpty(csvRow))
                    {
                        //Add new row in the database
                        tblcsv.Rows.Add();
                        int count = 0;
                        foreach (string fileRec in csvRow.Split(','))
                        {
                            tblcsv.Rows[tblcsv.Rows.Count - 1][count] = fileRec;
                            count++;
                        }
                    }

                }
                //Calling the insert method
                InsertCSVRecords(tblcsv);
            }catch(Exception ex){
                lblResult.Text =  ex.Message;
            }
        }

        protected void btnEdit_Click(object sender, EventArgs e)
        {
            try
            {
                comm = new SqlCommand("update Person_Infor set firstname=@Firstname, surname=@Surname, age=@Age" +
                                        "sex=@Sex, mobile=@Mobile");
                comm.Parameters.AddWithValue("@Firstname", ddlName.SelectedIndex.ToString());
                comm.Parameters.AddWithValue("@Surname", txtSurname.Text);
                comm.Parameters.AddWithValue("@Age", int.Parse(txtAge.Text));
                comm.Parameters.AddWithValue("@Sex", char.Parse(txtGender.Text));
                comm.Parameters.AddWithValue("@Mobile", txtMobile.Text);
                dbConnection.Open();

                int count = 0;
                if (count > 0)
                {
                    lblResult.Text = "Data is updated";
                }
            }
            catch (IndexOutOfRangeException ex)
            {

                lblResult.Text = ex.Message;
            }
            finally
            {
                dbConnection.Close();
            }
        }

        protected void btnAdd_Click(object sender, EventArgs e)
        {
            /*
            try
            {

                comm = new SqlCommand("insert into Person_Infor values(ID, FirstName, Surname, Age, Sex, Mobile, Active)", dbConnection);
                comm.Parameters.AddWithValue("@FirstName", txtFirstName.Text);
                comm.Parameters.AddWithValue("@Surname", txtSurname.Text);
                comm.Parameters.AddWithValue("@Age", int.Parse(txtAge.Text));
                comm.Parameters.AddWithValue("@Sex", char.Parse(txtSex.Text));
                comm.Parameters.AddWithValue("@Mobile", txtMobile.Text);
                //comm.Parameters.AddWithValue("@Active", t);
                dbConnection.Open();
                int a = comm.ExecuteNonQuery();
                if (a > 0)
                {
                    lblResult.Text = "Data is submitted";
                }
            }
            catch (Exception ex)
            {
                lblResult.Text = ex.Message;
            }
           */
        }

        protected void bntDelete_Click(object sender, EventArgs e)
        {
            try
            {
                comm = new SqlCommand("Delete from Person_Infor where ID = @ID", dbConnection);
                comm.Parameters.AddWithValue("@ID", ddlDelete.SelectedItem.ToString());
                dbConnection.Open();
                int num = comm.ExecuteNonQuery();

                if (num > 0)
                {
                    lblResult.Text = " Iterm is Deleted";

                }

            }
            catch (IndexOutOfRangeException ex)
            {

                lblResult.Text = ex.Message;
            }
            finally
            {
                dbConnection.Close();
            }
        }

        protected void btnShow_Click(object sender, EventArgs e)
        {

            try
            {

                comm = new SqlCommand("Select * from Person_infor", dbConnection);
                dbConnection.Open();
                read = comm.ExecuteReader();
                if (read.HasRows)
                {
                    DataTable dataTable = new DataTable();
                    dataTable.Load(read);
                    listDisplay.DataSource = dataTable;
                }
            }
            catch (IndexOutOfRangeException ex)
            {

                lblResult.Text = ex.Message;
            }
            finally
            {
                dbConnection.Close();
            }
        }
    }
}
