﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;
using System.IO;
using System.Data.SqlClient;

namespace MyPerson
{
    public class Person
    {
        private string firstname;
        private string surname;
        private DateTime dob;
        private char gender;
        private string mobile;

        public Person()
        {

        }

        public void setPerson(string name, string sur, DateTime dob, char sex, string mphone)
        {
            firstname = name;
            surname = sur;
            this.dob = dob;
            gender = sex;
            mobile = mphone;
        }

        public void setFirstName(string name)
        {
            firstname = name;
        }

        public string getFirstName()
        {
            string nam = "";
            if (firstname.Length > 0)
            {
                nam = this.surname + " " + firstname[0];
            }
            return nam;
        }

        public void setSurname(string sur)
        {
            surname = sur;
        }

        public string getSurname()
        {
           
            return surname;
        }

        public void setDob(DateTime dob)
        {
            this.dob = dob;
        }
        public DateTime getDob()
        {
            return dob;
        }
        public int getAge()
        {
            int age = DateTime.Now.Year - dob.Year;
            return age;
        }

        public void setGender(char sex)
        {
            gender = sex;
        }

        public char get()
        {
            return gender;
        }

        public void setMobile(string mphone)
        {
            mobile = mphone;
        }

        public string getMobile()
        {
            return mobile;
        }

        public virtual string display()
        {
            string result = "";
            result = "Firstname" + firstname + " " + "Surname" + surname + "\t";
            result += "Age" + dob + " " + "Sex" + gender + "\t";
            result += "Mobile" + mobile;

            return result;
        }
    }
}
